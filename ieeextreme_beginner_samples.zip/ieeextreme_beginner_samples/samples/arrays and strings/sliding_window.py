# PROBLEM: Find the largest sum of any K consecutive numbers.
# INPUT: N K, then N numbers.
# OUTPUT: Largest window sum.

n, k = map(int, input().split())
numbers = list(map(int, input().split()))

if k < 1 or k > n:
    print("INVALID")
else:
    current = sum(numbers[:k])  # Sum the first window.
    best = current

    for i in range(k, n):
        # Remove the value leaving the window and add the new value.
        current = current - numbers[i - k] + numbers[i]
        best = max(best, current)

    print(best)
