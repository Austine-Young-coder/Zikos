# PROBLEM: Find the first position of a pattern in a text, or -1.
# INPUT: text on first line, pattern on second line.
# OUTPUT: Zero-based starting index.

text = input().strip()
pattern = input().strip()

# Simple method: check each possible starting position.
answer = -1
for i in range(len(text) - len(pattern) + 1):
    if text[i:i + len(pattern)] == pattern:
        answer = i
        break

print(answer)
