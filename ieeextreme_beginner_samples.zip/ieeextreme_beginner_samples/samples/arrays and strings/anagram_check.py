# PROBLEM: Check whether two words contain the same letters in any order.
# INPUT: listen / silent
# OUTPUT: YES

first = input().strip()
second = input().strip()

# Sorting the letters makes anagrams have the same sorted result.
if sorted(first) == sorted(second):
    print("YES")
else:
    print("NO")
