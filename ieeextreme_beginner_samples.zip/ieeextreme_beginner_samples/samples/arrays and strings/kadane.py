# PROBLEM: Find the maximum sum of a non-empty contiguous subarray.
# INPUT: N then N integers.
# OUTPUT: Maximum subarray sum.

n = int(input())
numbers = list(map(int, input().split()))
current = numbers[0]
best = numbers[0]

for number in numbers[1:]:
    current = max(number, current + number)
    best = max(best, current)

print(best)
