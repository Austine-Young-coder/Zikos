# PROBLEM: Find whether a sorted list contains two numbers adding to target.
# INPUT: N target, then sorted numbers.
# OUTPUT: YES or NO

n, target = map(int, input().split())
numbers = list(map(int, input().split()))
left = 0
right = n - 1
found = False

while left < right:
    total = numbers[left] + numbers[right]

    if total == target:
        found = True
        break
    elif total < target:
        left += 1  # Need a larger sum.
    else:
        right -= 1  # Need a smaller sum.

print("YES" if found else "NO")
