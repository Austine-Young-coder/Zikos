# PROBLEM: Answer sums of ranges [left, right], with zero-based indices.
# INPUT: N, numbers, Q, then Q lines containing left right.

n = int(input())
numbers = list(map(int, input().split()))
prefix = [0]  # Sum of zero numbers is zero.

for number in numbers:
    prefix.append(prefix[-1] + number)

q = int(input())
for i in range(q):
    left, right = map(int, input().split())
    # Subtract the sum before left from the sum through right.
    print(prefix[right + 1] - prefix[left])
