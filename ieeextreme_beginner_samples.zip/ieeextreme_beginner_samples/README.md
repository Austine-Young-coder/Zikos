# IEEEXtreme Beginner Python Samples

A learning repository for a three-person team preparing for competitive programming.

## How to use it
1. Open a `.py` file in PyCharm or another Python editor.
2. Read the problem statement at the top.
3. Run the sample input shown in the comments.
4. Change the input and test edge cases.
5. Explain the algorithm to another teammate before relying on it.

## Folder guide
- `samples/sorting/`: sorting algorithms
- `samples/search/`: search techniques
- `samples/dynamic programming/`: DP examples
- `samples/greedy algorithm/`: greedy strategies
- `samples/number theory/`: GCD, primes and factors
- `samples/modular arithmetic/`: arithmetic with remainders
- `samples/recursion/`: recursive examples
- `samples/stacks and queues/`: stack, queue and monotonic-stack examples
- `samples/bit manipulator/`: bitwise operations
- `samples/loops and functions/`: Python fundamentals
- `samples/graphs/`: graph traversal and paths
- `samples/data structures/`: common data structures
- `samples/arrays and strings/`: common array and string techniques

## Important
These are beginner teaching examples, not a guarantee that every solution fits every contest limit. Check constraints, input format and edge cases for each problem. Some examples explicitly use simple methods to demonstrate the idea before learning optimized versions.

Use code and collaboration tools during an actual contest only when the applicable official task rules permit them.
